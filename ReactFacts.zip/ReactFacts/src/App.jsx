import Navbar from "./Components/Navbar"
import MainComponent from "./Components/MainComponent"

export default function App() {
  return(
   <div>
  <Navbar/>
  <MainComponent/>
  </div> )
}