export default function MainComponent() {
    return (
    <main>MainComponent goes here</main>
    )
}