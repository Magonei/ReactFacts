export default function Footer() {
    return (
      <footer>
        <small>© 2025 <span>Gonz&aacute;lez</span> development. All rights reserved.</small>
      </footer>
    )
  }